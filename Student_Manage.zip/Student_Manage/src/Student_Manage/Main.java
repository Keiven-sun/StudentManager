package Student_Manage;

public class Main {

	 public static void main(String[] args) {
		new Login();
	    }

}
